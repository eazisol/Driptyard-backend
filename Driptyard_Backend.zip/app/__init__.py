"""
Driptyard Backend - C2C E-commerce Platform

A FastAPI-based backend for consumer-to-consumer e-commerce platform.
"""

__version__ = "1.0.0"
__author__ = "Driptyard Team"
