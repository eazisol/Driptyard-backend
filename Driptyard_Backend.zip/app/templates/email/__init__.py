"""
Email templates package.

This package contains HTML email templates.
"""