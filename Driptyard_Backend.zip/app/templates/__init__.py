"""
Templates package.

This package contains all HTML templates for emails and other content.
"""